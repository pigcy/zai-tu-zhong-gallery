(() => {
  const hero = document.querySelector('.hero-film');
  const feature = hero.querySelector('.hero-feature');
  const media = feature.querySelector('.hero-media');
  const poster = hero.querySelector('.hero-poster');
  const video = hero.querySelector('video');
  const toggle = hero.querySelector('.hero-video-toggle');
  const header = document.querySelector('.site-header');
  const lightbox = document.querySelector('#lightbox');
  const motion = matchMedia('(prefers-reduced-motion: reduce)');
  let heroVisible = false;
  let pageHidden = false;
  let posterPainted = false;
  let autoplayBlocked = false;
  let playback = 'auto';
  let scrollFrame = 0;

  function updateScroll() {
    scrollFrame = 0;
    const unfoldDistance = Math.max(140, feature.offsetTop - innerHeight * .24);
    const progress = Math.min(1, Math.max(0, scrollY / unfoldDistance));
    header.classList.toggle('is-scrolled', scrollY > 34);
    if (!motion.matches) media.style.setProperty('--film-progress', progress.toFixed(3));
  }

  function requestScrollUpdate() {
    if (!scrollFrame) scrollFrame = requestAnimationFrame(updateScroll);
  }

  function updateControl() {
    const playing = !video.paused;
    toggle.toggleAttribute('data-playing', playing);
    toggle.setAttribute('aria-label', playing ? '暂停背景视频' : '播放背景视频');
  }

  function showPoster() {
    hero.classList.remove('has-video-frame');
  }

  function mediaFailed() {
    showPoster();
    toggle.hidden = true;
  }

  function syncPlayback() {
    const wantsPlayback = playback === 'manual' || (playback === 'auto' && !autoplayBlocked && !motion.matches);
    if (!posterPainted || !heroVisible || pageHidden || document.hidden || lightbox.open || !wantsPlayback) {
      if (!video.paused) video.pause();
      return;
    }
    if (toggle.hidden || !video.paused) return;
    if (!video.hasAttribute('src')) video.src = video.dataset.src;
    video.play().catch(error => {
      if (error.name === 'AbortError') return;
      if (error.name === 'NotAllowedError') {
        autoplayBlocked = true;
        playback = 'auto';
        showPoster();
        updateControl();
      } else {
        mediaFailed();
      }
    });
  }

  toggle.addEventListener('click', () => {
    playback = video.paused ? 'manual' : 'paused';
    syncPlayback();
  });
  video.addEventListener('play', updateControl);
  video.addEventListener('pause', updateControl);
  video.addEventListener('error', mediaFailed);
  video.addEventListener('playing', () => {
    if (!video.paused) hero.classList.add('has-video-frame');
  });

  // Exclude the fixed navigation and the gutter above the gallery anchor.
  new IntersectionObserver(([entry]) => {
    heroVisible = entry.isIntersecting;
    document.documentElement.dataset.heroVisible = String(heroVisible);
    syncPlayback();
  }, { rootMargin: '-92px 0px 0px' }).observe(media);
  new MutationObserver(syncPlayback).observe(lightbox, { attributes: true, attributeFilter: ['open'] });
  document.addEventListener('visibilitychange', syncPlayback);
  window.addEventListener('pagehide', () => { pageHidden = true; syncPlayback(); });
  window.addEventListener('pageshow', () => { pageHidden = false; requestScrollUpdate(); syncPlayback(); });
  window.addEventListener('scroll', requestScrollUpdate, { passive: true });
  window.addEventListener('resize', requestScrollUpdate, { passive: true });
  motion.addEventListener('change', () => {
    if (motion.matches) {
      if (playback === 'manual') playback = 'auto';
      showPoster();
    }
    requestScrollUpdate();
    syncPlayback();
  });
  updateScroll();

  // Give the decoded poster a paint before requesting the video.
  poster.decode().catch(() => {}).then(() => {
    requestAnimationFrame(() => requestAnimationFrame(() => {
      posterPainted = true;
      toggle.hidden = false;
      syncPlayback();
    }));
  });
})();

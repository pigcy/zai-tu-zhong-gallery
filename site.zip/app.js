const grid = document.querySelector('#photo-grid');
const statusText = document.querySelector('#gallery-status');
const filters = [...document.querySelectorAll('[data-filter]')];
const dialog = document.querySelector('#lightbox');
const image = document.querySelector('#lightbox-image');
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
let photos = [];
let visiblePhotos = [];
let activeIndex = 0;
let opener = null;
let dialogAnimation;
let closing = false;

function applyFilter(category) {
  filters.forEach(button => {
    const active = button.dataset.filter === category;
    button.classList.toggle('active', active);
    button.setAttribute('aria-pressed', String(active));
  });
  visiblePhotos = photos.filter(photo => category === '全部' || photo.category === category);
  [...grid.children].forEach(card => {
    card.getAnimations().forEach(animation => animation.cancel());
    card.hidden = !visiblePhotos.some(photo => photo.id === card.dataset.id);
    if (!card.hidden && !reducedMotion.matches) {
      card.animate([{ opacity: .35, transform: 'translateY(9px)' }, { opacity: 1, transform: 'translateY(0)' }], { duration: 300, easing: 'cubic-bezier(.22,.7,.18,1)' });
    }
  });
  statusText.textContent = `显示${category === '全部' ? '全部影像' : category + '影像'}，共 ${visiblePhotos.length} 张`;
}

function renderPhotos() {
  photos.forEach((photo, index) => {
    const card = document.createElement('article');
    card.className = 'photo-card';
    card.dataset.id = photo.id;
    const button = document.createElement('button');
    button.className = 'photo-button';
    button.dataset.photo = photo.id;
    button.setAttribute('aria-label', `查看示例影像：${photo.title}，${photo.category}`);
    const thumbnail = document.createElement('img');
    thumbnail.src = photo.src;
    thumbnail.alt = photo.alt;
    thumbnail.loading = 'lazy';
    thumbnail.width = 900;
    thumbnail.height = 1058;
    const badge = document.createElement('span');
    badge.className = 'photo-badge';
    badge.textContent = '示例影像';
    const expand = document.createElement('span');
    expand.className = 'photo-expand';
    expand.textContent = '↗';
    expand.setAttribute('aria-hidden', 'true');
    button.append(thumbnail, badge, expand);
    const meta = document.createElement('div');
    meta.className = 'photo-meta';
    const title = document.createElement('h3');
    title.textContent = photo.title;
    const number = document.createElement('span');
    number.textContent = String(index + 1).padStart(2, '0');
    meta.append(title, number);
    const subtitle = document.createElement('p');
    subtitle.className = 'photo-subtitle';
    subtitle.textContent = `${photo.category} / ${photo.subtitle}`;
    card.append(button, meta, subtitle);
    grid.append(card);
  });
  grid.setAttribute('aria-busy', 'false');
  applyFilter('全部');
}

function showPhoto(index) {
  activeIndex = (index + visiblePhotos.length) % visiblePhotos.length;
  const photo = visiblePhotos[activeIndex];
  image.getAnimations().forEach(animation => animation.cancel());
  image.src = photo.src;
  image.alt = photo.alt;
  document.querySelector('#lightbox-title').textContent = photo.title;
  document.querySelector('#lightbox-category').textContent = `${photo.category} / ${photo.subtitle}`;
  document.querySelector('#lightbox-counter').textContent = `${String(activeIndex + 1).padStart(2, '0')} / ${String(visiblePhotos.length).padStart(2, '0')}`;
  const source = document.querySelector('#lightbox-source');
  source.href = photo.source;
  source.textContent = `摄影：${photo.author} / Unsplash ↗`;
  if (!reducedMotion.matches) image.animate([{ opacity: .25 }, { opacity: 1 }], { duration: 230, easing: 'ease-out' });
}

function openPhoto(id, button) {
  if (!photos.length) return;
  const index = visiblePhotos.findIndex(photo => photo.id === id);
  if (index < 0) applyFilter('全部');
  opener = button;
  closing = false;
  dialogAnimation?.cancel();
  showPhoto(visiblePhotos.findIndex(photo => photo.id === id));
  document.body.style.overflow = 'hidden';
  dialog.showModal();
  if (!reducedMotion.matches) dialogAnimation = dialog.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 220, easing: 'ease-out' });
  document.querySelector('#lightbox-close').focus({ preventScroll: true });
}

function closePhoto() {
  if (closing || !dialog.open) return;
  closing = true;
  dialogAnimation?.cancel();
  const finish = () => {
    dialog.close();
    document.body.style.overflow = '';
    opener?.focus({ preventScroll: true });
    closing = false;
  };
  if (reducedMotion.matches) return finish();
  dialogAnimation = dialog.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 170, easing: 'ease-in', fill: 'forwards' });
  dialogAnimation.finished.then(finish).catch(() => {});
}

document.addEventListener('click', event => {
  const button = event.target.closest('[data-photo]');
  if (button) openPhoto(button.dataset.photo, button);
});
filters.forEach(button => button.addEventListener('click', () => applyFilter(button.dataset.filter)));
document.querySelectorAll('[data-collection]').forEach(link => link.addEventListener('click', () => applyFilter(link.dataset.collection)));
document.querySelector('#lightbox-close').addEventListener('click', closePhoto);
document.querySelector('#lightbox-prev').addEventListener('click', () => { if (!closing) showPhoto(activeIndex - 1); });
document.querySelector('#lightbox-next').addEventListener('click', () => { if (!closing) showPhoto(activeIndex + 1); });
dialog.addEventListener('cancel', event => { event.preventDefault(); closePhoto(); });
dialog.addEventListener('click', event => { if (event.target === dialog || event.target.classList.contains('lightbox-image-wrap')) closePhoto(); });
dialog.addEventListener('keydown', event => {
  if (closing) return;
  if (event.key === 'Tab') {
    const controls = [...dialog.querySelectorAll('button, a[href]')];
    const first = controls[0];
    const last = controls[controls.length - 1];
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  }
  if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
    event.preventDefault();
    showPhoto(activeIndex + (event.key === 'ArrowRight' ? 1 : -1));
  }
});

fetch('photos.json').then(response => {
  if (!response.ok) throw new Error('Photo data unavailable');
  return response.json();
}).then(data => { photos = data; renderPhotos(); }).catch(() => {
  grid.setAttribute('aria-busy', 'false');
  document.querySelector('#gallery-error').hidden = false;
});

/* Halftone light field, independently written for 在途中.
   Visual reference: OriginKit / Halftone Bloom, inspected 2026-11-08.
   No OriginKit source code or runtime dependencies are included. */
(() => {
  'use strict';
  const canvas = document.querySelector('#halftone-bloom');
  const gl = canvas.getContext('webgl', { alpha: false, antialias: false, depth: false, powerPreference: 'low-power' });
  if (!gl) { canvas.dataset.renderer = 'fallback'; return; }
  const vertexSource = `
    attribute vec2 position;
    varying vec2 uv;
    void main() { uv = position * .5 + .5; gl_Position = vec4(position, 0., 1.); }
  `;
  const fieldSource = `
    precision highp float;
    varying vec2 uv;
    uniform vec2 resolution;
    uniform float time;
    void main() {
      vec2 p = (uv - .5) * vec2(resolution.x / resolution.y, 1.) * 2.;
      p.x += .10 * sin(time * .08);
      vec3 light = vec3(0.);
      // Stacked folds accumulate into a broad, breathing arc.
      for (int i = 0; i < 48; i++) {
        float layer = float(i) / 47.;
        float wave = .33 * sin(p.x * 1.12 + layer * 1.7 + time * .14)
                   + .15 * sin(p.x * 2.15 - layer * .7 - time * .11);
        float ridge = p.y + .60 + wave - layer * .72;
        float fold = .00034 / (ridge * ridge + .00085);
        float shade = .5 + .5 * sin(layer * 7. + p.x * .50 + time * .10);
        vec3 tint = mix(vec3(1., .19, .17), vec3(1., .55, .17), shade);
        light += tint * fold * .26;
      }
      light *= .72 + .28 * cos(p.x * .56 - .3);
      vec3 color = 1. - exp(-light * 1.18);
      gl_FragColor = vec4(color, 1.);
    }
  `;
  const screenSource = `
    precision highp float;
    varying vec2 uv;
    uniform sampler2D field;
    uniform vec2 resolution;
    uniform vec2 pointer;
    uniform float hover;
    uniform float pixelRatio;
    mat2 rotate(float a) { return mat2(cos(a), -sin(a), sin(a), cos(a)); }
    void main() {
      float cellSize = 6. * pixelRatio;
      vec2 pixel = uv * resolution;
      vec2 grid = rotate(.31) * (pixel - resolution * .5);
      vec2 centre = (floor(grid / cellSize) + .5) * cellSize;
      vec2 samplePoint = rotate(-.31) * centre + resolution * .5;
      vec3 tone = texture2D(field, clamp(samplePoint / resolution, .001, .999)).rgb;
      vec3 smoothField = texture2D(field, uv).rgb;
      float luma = dot(tone, vec3(.2126, .7152, .0722));
      float reach = min(429. * pixelRatio, resolution.x * .68);
      float proximity = 1. - smoothstep(0., reach, distance(samplePoint, pointer));
      proximity *= hover;
      float radius = min(.645, sqrt(luma) * (.48 + .20 * proximity)) * cellSize;
      float edge = max(.55, pixelRatio * .55);
      float dotMask = 1. - smoothstep(radius - edge, radius + edge, length(grid - centre));
      vec3 pigment = mix(tone * 1.52, vec3(1., .86, .66), pow(luma, 3.) * .5);
      vec3 printed = pigment * dotMask;
      vec3 color = mix(smoothField * .34, printed, .84 + .16 * proximity);
      color += smoothField * (.065 + .03 * proximity);
      // Gentle grain-sized dots, with black gaps even in a full bloom.
      gl_FragColor = vec4(color + vec3(.018, .014, .011), 1.);
    }
  `;
  function program(fragmentSource) {
    const result = gl.createProgram();
    for (const [type, source] of [[gl.VERTEX_SHADER, vertexSource], [gl.FRAGMENT_SHADER, fragmentSource]]) {
      const shader = gl.createShader(type);
      gl.shaderSource(shader, source);
      gl.compileShader(shader);
      if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) throw new Error('Background shader compilation failed');
      gl.attachShader(result, shader);
      gl.deleteShader(shader);
    }
    gl.linkProgram(result);
    if (!gl.getProgramParameter(result, gl.LINK_STATUS)) throw new Error('Background shader link failed');
    return result;
  }
  let fieldProgram, screenProgram;
  try { fieldProgram = program(fieldSource); screenProgram = program(screenSource); }
  catch { canvas.dataset.renderer = 'fallback'; canvas.hidden = true; return; }
  const quad = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, quad);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1, 1,-1, -1,1, -1,1, 1,-1, 1,1]), gl.STATIC_DRAW);
  const texture = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  const target = gl.createFramebuffer();
  gl.bindFramebuffer(gl.FRAMEBUFFER, target);
  gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, texture, 0);
  const location = (p, name) => gl.getUniformLocation(p, name);
  const fieldUniforms = { resolution: location(fieldProgram, 'resolution'), time: location(fieldProgram, 'time') };
  const screenUniforms = Object.fromEntries(['resolution','pointer','hover','pixelRatio','field'].map(name => [name, location(screenProgram, name)]));
  const motion = matchMedia('(prefers-reduced-motion: reduce)');
  const lightbox = document.querySelector('#lightbox');
  const controller = new AbortController();
  const options = { passive: true, signal: controller.signal };
  let width, height, ratio, fieldWidth, fieldHeight, frame = 0, lastFrame = 0, phase = 4.8, disposed = false;
  let active = false, hover = 0, desiredHover = 0, pageHidden = false;
  let x = innerWidth * .65, y = innerHeight * .65, desiredX = x, desiredY = y;
  function bind(p) {
    gl.useProgram(p);
    gl.bindBuffer(gl.ARRAY_BUFFER, quad);
    const attribute = gl.getAttribLocation(p, 'position');
    gl.enableVertexAttribArray(attribute);
    gl.vertexAttribPointer(attribute, 2, gl.FLOAT, false, 0, 0);
  }
  function draw() {
    gl.bindFramebuffer(gl.FRAMEBUFFER, target);
    gl.viewport(0, 0, fieldWidth, fieldHeight);
    bind(fieldProgram);
    gl.uniform2f(fieldUniforms.resolution, width, height);
    gl.uniform1f(fieldUniforms.time, phase);
    gl.drawArrays(gl.TRIANGLES, 0, 6);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.viewport(0, 0, width, height);
    bind(screenProgram);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.uniform1i(screenUniforms.field, 0);
    gl.uniform2f(screenUniforms.resolution, width, height);
    gl.uniform2f(screenUniforms.pointer, x * ratio, height - y * ratio);
    gl.uniform1f(screenUniforms.hover, hover);
    gl.uniform1f(screenUniforms.pixelRatio, ratio);
    gl.drawArrays(gl.TRIANGLES, 0, 6);
  }
  function tick(now) {
    if (!active) return;
    frame = requestAnimationFrame(tick);
    const step = innerWidth < 761 ? 50 : 1000 / 30;
    if (lastFrame && now - lastFrame < step - 1) return;
    const dt = lastFrame ? Math.min((now - lastFrame) / 1000, .08) : 0;
    lastFrame = now;
    phase += dt;
    const follow = 1 - Math.exp(-dt * 6);
    x += (desiredX - x) * follow;
    y += (desiredY - y) * follow;
    hover += (desiredHover - hover) * follow;
    draw();
  }
  function updateState() {
    cancelAnimationFrame(frame);
    active = !disposed && !pageHidden && !document.hidden && !lightbox.open &&
      !motion.matches && document.documentElement.dataset.heroVisible !== 'true';
    canvas.dataset.motion = active ? 'running' : motion.matches ? 'reduced' : 'paused';
    lastFrame = 0;
    if (active) frame = requestAnimationFrame(tick);
    else if (!disposed && !pageHidden && !document.hidden && !lightbox.open) { hover = 0; draw(); }
  }
  function resize() {
    ratio = Math.min(devicePixelRatio || 1, 1.5, Math.sqrt(1800000 / (innerWidth * innerHeight)));
    width = canvas.width = Math.max(1, Math.round(innerWidth * ratio));
    height = canvas.height = Math.max(1, Math.round(innerHeight * ratio));
    fieldWidth = Math.max(1, Math.round(width * .45));
    fieldHeight = Math.max(1, Math.round(height * .45));
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, fieldWidth, fieldHeight, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    gl.bindFramebuffer(gl.FRAMEBUFFER, target);
    if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) { dispose(); return; }
    if (!disposed) { draw(); updateState(); }
  }
  function dispose() {
    disposed = true;
    active = false;
    cancelAnimationFrame(frame);
    observer.disconnect();
    controller.abort();
    motion.removeEventListener('change', updateState);
    gl.deleteFramebuffer(target);
    gl.deleteTexture(texture);
    gl.deleteBuffer(quad);
    gl.deleteProgram(fieldProgram);
    gl.deleteProgram(screenProgram);
    canvas.hidden = true;
    canvas.dataset.renderer = 'fallback';
  }
  const observer = new MutationObserver(updateState);
  observer.observe(lightbox, { attributes: true, attributeFilter: ['open'] });
  observer.observe(document.documentElement, { attributes: true, attributeFilter: ['data-hero-visible'] });
  window.addEventListener('pointermove', event => {
    if (event.pointerType === 'touch' || motion.matches || lightbox.open) return;
    desiredX = event.clientX; desiredY = event.clientY; desiredHover = 1;
  }, options);
  document.documentElement.addEventListener('pointerleave', () => { desiredHover = 0; }, options);
  window.addEventListener('blur', () => { desiredHover = 0; }, options);
  window.addEventListener('resize', resize, options);
  document.addEventListener('visibilitychange', updateState, options);
  window.addEventListener('pagehide', event => { pageHidden = true; if (event.persisted) updateState(); else dispose(); }, options);
  window.addEventListener('pageshow', () => { pageHidden = false; updateState(); }, options);
  canvas.addEventListener('webglcontextlost', event => { event.preventDefault(); dispose(); }, { signal: controller.signal });
  motion.addEventListener('change', updateState);
  canvas.dataset.renderer = 'webgl';
  resize();
})();
